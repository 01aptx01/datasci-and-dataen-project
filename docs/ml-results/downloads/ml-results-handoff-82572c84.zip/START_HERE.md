# DEDS ML Results Handoff

This offline bundle contains one frozen Stage 06 result set, a read-only notebook, figures, Markdown notes, a standalone HTML report, and QA evidence.

## Open the report

Open `report/ml_results_review.html` in a browser. It is self-contained and does not need internet access or Python.

## Inspect or rerun the notebook

Open `notebook/03_ml_results_review.ipynb` in Jupyter. It reads the CSV and JSON files in `approved_results/` only. It does not train or replay models, run forecasts, or recompute hypotheses. To run it from another folder, set `DEDS_RESULTS_DIR` to this bundle's `approved_results` directory.

## Verify the files

`source_identity.json` records the Evaluation ID, Replay ID, source hashes, code/config identity, lineage and limitations. `CHECKSUMS.sha256` covers every file in this bundle except itself. Use `qa/verification_report.json` and `report/verification_report.md` for the executed checks.

## Frozen run

- Evaluation ID: `82572c8417041976e1ce540d921e29a5f28c1d5d2a2d953a74c03582e7ca9be2`
- Final Replay ID: `3cbf81eb9242d8894d2f67f39065a17ff1ef55a2e098773aead915949ab11b12`
- Assets: SPY, IEF, GLD
- Test period and strict data cutoff: 2025-10-01 through 2026-09-25
- Values are annualized decimal unless a field says otherwise.

## Limitations and approval status

This is a review handoff, not a report approved for publication. The replay is simulated historical replay using a later-downloaded snapshot; point-in-time data availability is not verified. The H1 manifest recorded a dirty working tree, and the exact uncommitted H1 source-code state is not archived. Peer review and an approved team-share location are still pending.
