# Stage 06 Final Evaluation

- Evaluation ID: `82572c8417041976e1ce540d921e29a5f28c1d5d2a2d953a74c03582e7ca9be2`
- Test: 2025-10-01 through 2026-09-25; predictions come from the completed Final Replay.
- Test data were not used to select models, hyperparameters, features, thresholds, or methods.

## Test error on the common B0-B3 panel

| Model | SPY MAE | IEF MAE | GLD MAE | Macro MAE | Macro RMSE |
|---|---:|---:|---:|---:|---:|
| CONSTANT_BASELINE | 0.051733 | 0.037564 | 0.138264 | 0.075854 | 0.119245 |
| ROLLING_20D_BASELINE | 0.044734 | 0.012243 | 0.121045 | 0.059340 | 0.099953 |
| STATIC_SGD | 0.039142 | 0.011510 | 0.106786 | 0.052479 | 0.099039 |
| ONLINE_SGD | 0.038557 | 0.011503 | 0.096618 | 0.048892 | 0.093403 |

## Primary paired comparisons

Positive DeltaMAE means B3 has lower paired absolute error than the baseline. Deltas are annualized-decimal values.

| Comparison | Macro DeltaMAE | Relative improvement (%) | Paired N |
|---|---:|---:|---:|
| B0 (B3 vs CONSTANT_BASELINE) | 0.026961 | 35.54 | 729 |
| H3 (B3 vs ROLLING_20D_BASELINE) | 0.010448 | 17.61 | 729 |
| H2 (B3 vs STATIC_SGD) | 0.003587 | 6.83 | 729 |

## Hypothesis decisions

| Hypothesis | Scope | Effect | Raw p | Holm-adjusted p | Decision |
|---|---|---:|---:|---:|---|
| H1 | SPY | 0.567075 | 0.000000 | 0.000000 | Reject H₀ |
| H1 | IEF | 0.274968 | 0.000001 | 0.000003 | Reject H₀ |
| H1 | GLD | 0.190001 | 0.002354 | 0.002354 | Reject H₀ |
| H2 | MACRO | 0.003587 | 0.001000 | 0.001999 | Reject H₀ |
| H3 | MACRO | 0.010448 | 0.005997 | 0.005997 | Reject H₀ |

## Coverage

- Test expected anchors across ETF/model rows: 2976.
- Valid forecasts: 2976; invalid/missing forecasts: 0.
- Pending labels: 60; these are not forecast failures.

## Limits and interpretation

- The historical source snapshot was downloaded after the replay period. Point-in-time source availability is not verified; this is a Simulated Historical Replay.
- Test estimates describe this frozen historical snapshot and replay protocol. They do not establish prospective live performance or causality.
- H1 is a Train-only association test and does not establish forecast superiority. Non-significance is a valid result.
- Portfolio risk is a forecast-based historical diagnostic; the default 50/30/20 weights can be changed in the consumer without retraining.
