# Stage 06 Final Evaluation

- Evaluation ID: `12b9f92cbdcbb7816a767f8565bb004f3243b114480e5f3f316c497af4014e76`
- Test: 2025-10-01 through 2026-09-25; predictions come from the completed Final Replay.
- Test data were not used to select models, hyperparameters, features, thresholds, or methods.

## Test error on the common B0-B4 panel

| Model | SPY MAE | IEF MAE | GLD MAE | Macro MAE | Macro RMSE |
|---|---:|---:|---:|---:|---:|
| CONSTANT_BASELINE | 0.051733 | 0.037564 | 0.138264 | 0.075853 | 0.119245 |
| ROLLING_20D_BASELINE | 0.044734 | 0.012243 | 0.121045 | 0.059340 | 0.099953 |
| STATIC_SGD | 0.039142 | 0.011510 | 0.106786 | 0.052479 | 0.099039 |
| ONLINE_SGD | 0.038557 | 0.011503 | 0.096618 | 0.048892 | 0.093403 |
| HAR_X_OLS | 0.036457 | 0.014575 | 0.102163 | 0.051065 | 0.094657 |

## Primary paired comparisons

Positive DeltaMAE means B3 has lower paired absolute error than the baseline. Deltas are annualized-decimal values.

| Comparison | Macro DeltaMAE | Relative improvement (%) | Paired N |
|---|---:|---:|---:|
| B0 (B3 vs CONSTANT_BASELINE) | 0.026961 | 35.54 | 729 |
| H3 (B3 vs ROLLING_20D_BASELINE) | 0.010448 | 17.61 | 729 |
| H2 (B3 vs STATIC_SGD) | 0.003587 | 6.83 | 729 |

## B4 (HAR-X OLS) retrospective paired comparisons

Positive DeltaMAE means B4 (HAR_X_OLS) has lower paired absolute error than the comparator. These are retrospective non-hypothesis comparisons.

| Comparison | Macro DeltaMAE | Relative improvement (%) | Paired N |
|---|---:|---:|---:|
| B4_VS_B2 (B4 vs STATIC_SGD) | 0.001415 | 2.70 | 729 |
| B4_VS_B3 (B4 vs ONLINE_SGD) | -0.002172 | -4.44 | 729 |
| B4_VS_B1 (B4 vs ROLLING_20D_BASELINE) | 0.008276 | 13.95 | 729 |

## Hypothesis decisions

| Hypothesis | Scope | Effect | Raw p | Holm-adjusted p | Decision |
|---|---|---:|---:|---:|---|
| H1 | SPY | 0.567075 | 0.000000 | 0.000000 | Reject H₀ |
| H1 | IEF | 0.274954 | 0.000001 | 0.000003 | Reject H₀ |
| H1 | GLD | 0.190001 | 0.002354 | 0.002354 | Reject H₀ |
| H2 | MACRO | 0.003587 | 0.001000 | 0.001999 | Reject H₀ |
| H3 | MACRO | 0.010448 | 0.005997 | 0.005997 | Reject H₀ |

## Coverage

- Test expected anchors across ETF/model rows: 3720.
- Valid forecasts: 3720; invalid/missing forecasts: 0.
- Pending labels: 75; these are not forecast failures.

## Limits and interpretation

- The historical source snapshot was downloaded after the replay period. Point-in-time source availability is not verified; this is a Simulated Historical Replay.
- Test estimates describe this frozen historical snapshot and replay protocol. They do not establish prospective live performance or causality.
- H1 is a Train-only association test and does not establish forecast superiority. Non-significance is a valid result.
- Portfolio risk is a forecast-based historical diagnostic; the default 50/30/20 weights can be changed in the consumer without retraining.
