# Stage 06 Exploratory Policy Evaluation: Drift-Triggered Champion–Challenger

- **Policy Evaluation Version:** `1.2.0`
- **Evaluation ID:** `f6dd8cb131d7d7bebaefa0ca70f47e068956e5c2f4f99e448b1511711ddde844`
- **Replay Experiment ID:** `5003376f7637a3b04f63719dd499f67946aa3b0f30bafd27772e1d20d4ec9779`
- **Policy Version:** `1.0.0`
- **Policy Config Fingerprint:** `8f1934baf1c1815faea9632d9395c2c77264bd1af6ca06b8449b6d1bdd389059`
- **Confirmatory Hypotheses H1–H3:** Unchanged and evaluated strictly separately (`1.1.0`).

## Mandatory Limitations & Framing
1. **Exploratory / Test Reuse:** Exploratory retrospective policy specified after observing Stage 06 Test outcomes; reported strictly separately from confirmatory hypotheses H1-H3.
2. **Simulated Historical Replay / PIT:** Simulated historical replay (point_in_time_source_availability_verified=false); does not represent live inference or live operational retraining.
3. **Shadow Process vs Frozen Snapshot:** Paired challenger MAE evaluates the continuously updating shadow B3 process prior to decision time, whereas promotion serves a frozen pre-update B3 snapshot from the next session.

## Headline Test Summary (Matched Mature Panel)
- **Total Alerts:** `0` (`zero_alerts_observed=True`)
- **Total Decisions:** `0`
- **Total Promotions:** `0` (`zero_promotions_observed=True`)
- **Macro Policy MAE vs Fixed Initial Champion MAE:** `0.05247929706019636` vs `0.05247929706019636` (`delta=0.0`)

## Per-ETF Policy Metrics (Matched Mature Panel)

| Ticker | Strategy | Paired N | MAE | RMSE | Status |
| --- | --- | ---: | ---: | ---: | --- |
| SPY | CHAMPION_CHALLENGER_POLICY | 243 | 0.039142 | 0.054414 | COMPUTED |
| IEF | CHAMPION_CHALLENGER_POLICY | 243 | 0.011510 | 0.014623 | COMPUTED |
| GLD | CHAMPION_CHALLENGER_POLICY | 243 | 0.106786 | 0.162022 | COMPUTED |
| MACRO | CHAMPION_CHALLENGER_POLICY | 729 | 0.052479 | 0.099039 | COMPUTED |
| SPY | FIXED_INITIAL_CHAMPION | 243 | 0.039142 | 0.054414 | COMPUTED |
| IEF | FIXED_INITIAL_CHAMPION | 243 | 0.011510 | 0.014623 | COMPUTED |
| GLD | FIXED_INITIAL_CHAMPION | 243 | 0.106786 | 0.162022 | COMPUTED |
| MACRO | FIXED_INITIAL_CHAMPION | 729 | 0.052479 | 0.099039 | COMPUTED |
| SPY | SHADOW_B3 | 243 | 0.038557 | 0.053692 | COMPUTED |
| IEF | SHADOW_B3 | 243 | 0.011503 | 0.014564 | COMPUTED |
| GLD | SHADOW_B3 | 243 | 0.096618 | 0.151913 | COMPUTED |
| MACRO | SHADOW_B3 | 729 | 0.048892 | 0.093403 | COMPUTED |
| SPY | STATIC_SGD | 243 | 0.039142 | 0.054414 | COMPUTED |
| IEF | STATIC_SGD | 243 | 0.011510 | 0.014623 | COMPUTED |
| GLD | STATIC_SGD | 243 | 0.106786 | 0.162022 | COMPUTED |
| MACRO | STATIC_SGD | 729 | 0.052479 | 0.099039 | COMPUTED |
| SPY | ONLINE_SGD | 243 | 0.038557 | 0.053692 | COMPUTED |
| IEF | ONLINE_SGD | 243 | 0.011503 | 0.014564 | COMPUTED |
| GLD | ONLINE_SGD | 243 | 0.096618 | 0.151913 | COMPUTED |
| MACRO | ONLINE_SGD | 729 | 0.048892 | 0.093403 | COMPUTED |
| SPY | HAR_X_OLS | 243 | 0.036457 | 0.046306 | COMPUTED |
| IEF | HAR_X_OLS | 243 | 0.014575 | 0.017595 | COMPUTED |
| GLD | HAR_X_OLS | 243 | 0.102163 | 0.156288 | COMPUTED |
| MACRO | HAR_X_OLS | 729 | 0.051065 | 0.094657 | COMPUTED |
